﻿namespace ChipSecuritySystem
{
    public static class Constants
    {
        public const string ErrorMessage = "Cannot unlock master panel";
    }
}
